package com.example.loginintento8.data

import com.example.loginintento8.data.model.Usuario


@Deprecated("Se actualiza el proyecto para que se utilice room")//Linea para indicar obsolencia
object UsuarioDB {

    fun getUsuarios(): List<Usuario> {
        val usuarios = ArrayList<Usuario>()
        usuarios.add(crearUsuario("admin", "admin", "Nombre Completo Del Usuario"))
        usuarios.add(crearUsuario("goku", "goku", "Nombre Completo Del Usuario"))
        usuarios.add(crearUsuario("vegeta", "vegeta", "Nombre Completo Del Usuario"))
        usuarios.add(crearUsuario("homero", "homero", "Homer Jay Simpson"))
        return usuarios
    }

    private fun crearUsuario(usuario: String, password: String, nombreCompleto: String) =
        Usuario(usuario, nombreCompleto, password)

    fun loginConUsuarioYPassword(user: String, password: String): Usuario? {
        var usuarioRetorno: Usuario? = null
        getUsuarios().forEach { usuario ->
            if (usuario.password == password && usuario.nombre == user) {
                usuarioRetorno = usuario
                return@forEach
            }
        }
        return usuarioRetorno
    }



}