package com.example.loginintento8.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.loginintento8.data.model.Usuario


// se crea la base de datos que autentifica los datos

@Database(entities = [Usuario::class], version = 1) // Se declaran las entidades y la version de la base de datos
abstract class AuthenticationDatabase : RoomDatabase() { //Las base de datos corresponden a clases abstractas en este caso hereda del orm room

    abstract fun usuarioDao(): UsuarioDao  //Se crea una funcion abstracta que nos permite usar el dao que creamos

    companion object {

        @Volatile
        private var INSTANCE: AuthenticationDatabase? = null

        fun getDatabase(context: Context): AuthenticationDatabase {
            val tempInstance = INSTANCE
            if (tempInstance != null) {
                return tempInstance
            }

            synchronized(this) {
                val instance = Room.databaseBuilder(context.applicationContext,
                    AuthenticationDatabase::class.java,
                    "authentication_database")
                    .allowMainThreadQueries() // Esta linea de codigo permite que se generen las busquedas en el hilo principal
                    .build()
                INSTANCE = instance
                return instance
            }
        }
    }
}
