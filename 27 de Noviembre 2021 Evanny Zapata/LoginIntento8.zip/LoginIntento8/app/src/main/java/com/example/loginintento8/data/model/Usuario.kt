package com.example.loginintento8.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity //Se modifica nuestra data class que nos ayudaba a llenar la lista por una entidad, para crear una BD
data class Usuario(
    @PrimaryKey
    val nombre: String,
    val nombreCompleto: String, //Nuevo campo que nos permite registrar en el fragmento de registro el nombre de una cuenta
    val password: String
)