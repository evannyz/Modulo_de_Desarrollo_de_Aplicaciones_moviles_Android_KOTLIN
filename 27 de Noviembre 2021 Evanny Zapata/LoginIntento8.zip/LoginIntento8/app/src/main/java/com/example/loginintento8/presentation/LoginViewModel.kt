package com.example.loginintento8.presentation

import com.example.loginintento8.data.AuthenticationDatabase
import com.example.loginintento8.data.model.Usuario
import com.example.loginintento8.data.UsuarioDB
import com.example.loginintento8.data.UsuarioDao
import kotlinx.coroutines.launch
import android.app.Application
import androidx.lifecycle.*

class LoginViewModel(application: Application) : AndroidViewModel(application) {

    private val usuarioDao: UsuarioDao

    init {
        val dataBase = AuthenticationDatabase.getDatabase(application)
        usuarioDao = dataBase.usuarioDao()
    }

    private val mutableLiveData = MutableLiveData<String>()

    fun state() : LiveData<String> = mutableLiveData

    fun login(usuario: String, password: String){
        viewModelScope.launch{
            val findUser = usuarioDao.findUserByPassword(usuario, password)
            handleResponse(findUser)
        }
    }

    private fun handleResponse(usuario: Usuario?) {
        if(usuario != null){
            mutableLiveData.postValue(usuario.nombreCompleto)
        } else {
            mutableLiveData.postValue("Usuario no existe")
        }
    }

}