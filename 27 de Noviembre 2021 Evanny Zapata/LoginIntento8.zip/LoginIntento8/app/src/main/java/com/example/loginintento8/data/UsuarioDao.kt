package com.example.loginintento8.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.loginintento8.data.model.Usuario

@Dao //Se modificaLogin8 y se cra un Dao que corresponde al crud de sql, el Dao corresponde a una interface
interface UsuarioDao {
    @Insert //Inserta datos a las tablas creadas con las entidades y su relacion en la base de datos
    fun insertAll(vararg usuario: Usuario)
            //Se selecciona de la base de dato los registros donde coincida el nombre y la clave
    @Query("SELECT * FROM usuario WHERE nombre = :nombre AND password = :password")
    fun findUserByPassword(nombre: String, password: String): Usuario? //El usuario puede llegar a ser nulo

    @Query("SELECT * FROM usuario")
    fun getAllUsers(): List<Usuario>
    //Se recibe toda la lista de usuarios

}