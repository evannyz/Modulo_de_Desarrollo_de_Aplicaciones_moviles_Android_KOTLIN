package com.example.loginintento8.ui

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.activityViewModels
import com.example.loginintento8.databinding.FragmentRegistroBinding
import com.example.loginintento8.presentation.RegistroViewModel
import androidx.navigation.fragment.findNavController


class RegistroFragment : Fragment() {

    private var rawBinding: FragmentRegistroBinding? = null
    private val binding get() = rawBinding!!
    private val registroViewModel: RegistroViewModel by activityViewModels() //Esta linea se usa para no usar un provider.factory


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        rawBinding = FragmentRegistroBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupClickListener()
        setupViewModel()


    }

    private fun setupViewModel() {
        registroViewModel.state().observe(this) {
            it?.let { safeState ->
                renderUI(safeState)
            }
        }
    }

    private fun renderUI(safeState: String) {
        Toast.makeText(context, safeState, Toast.LENGTH_SHORT).show()
    }

    private fun setupClickListener() {
        binding.btnVolver.setOnClickListener {
            findNavController().popBackStack()
        }

        binding.btnRegistro.setOnClickListener {
            registroViewModel.registraUsuario(
                getNombre(),
                getPassword(),
                getNombreCompleto()
            )
        }
    }
    private fun getNombre() = binding.etUsuario.text.toString()
    private fun getPassword() = binding.etPassword.text.toString()
    private fun getNombreCompleto() = binding.etNombreCompleto.text.toString()


}