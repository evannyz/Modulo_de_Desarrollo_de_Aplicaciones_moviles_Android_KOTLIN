package com.example.loginintento8.presentation

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.loginintento8.data.AuthenticationDatabase
import com.example.loginintento8.data.UsuarioDao
import com.example.loginintento8.data.model.Usuario
import kotlinx.coroutines.launch



//Cada fragmento necesita su propio viewmodel que abise los cambios en las vistas
class RegistroViewModel(application: Application) : AndroidViewModel(application) {

    private val mutableState = MutableLiveData<String>()
    private val usuarioDao: UsuarioDao

    fun state(): LiveData<String> = mutableState

    init {
        val dataBase = AuthenticationDatabase.getDatabase(application)
        usuarioDao = dataBase.usuarioDao()
    }

    fun registraUsuario(nombre: String, password: String, nombreCompleto: String) {
        viewModelScope.launch {
            usuarioDao.insertAll(Usuario(nombre, nombreCompleto, password))
            val findUserByPassword = usuarioDao.findUserByPassword(nombre, password)
            handleState(findUserByPassword)
        }
    }

    private fun handleState(usuario: Usuario?) {
        if (usuario == null) {
            mutableState.postValue("No se registro usuario")
        } else {
            mutableState.postValue("Usuario: ${usuario.nombreCompleto}")
        }
    }
}