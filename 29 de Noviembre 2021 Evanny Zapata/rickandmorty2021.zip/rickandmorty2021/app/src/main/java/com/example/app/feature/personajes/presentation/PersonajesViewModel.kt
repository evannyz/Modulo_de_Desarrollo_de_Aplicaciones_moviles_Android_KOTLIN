package com.example.app.feature.personajes.presentation

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel

class PersonajesViewModel(application: Application) : AndroidViewModel(application) {

}