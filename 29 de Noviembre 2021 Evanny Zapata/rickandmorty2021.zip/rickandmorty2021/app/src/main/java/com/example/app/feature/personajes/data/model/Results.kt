package com.example.app.feature.personajes.data.model

data class Results(
    val personajesList: List<Personaje>
)
