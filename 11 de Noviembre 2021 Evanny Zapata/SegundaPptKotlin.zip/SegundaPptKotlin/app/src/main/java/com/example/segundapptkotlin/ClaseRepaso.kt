package com.example.segundapptkotlin


//Al igual que en Java en Kotlin se usan clases como plantillas o modelos para crear objetos
//Se definen de la misma manera con la declaracion class


class Persona(text: String) { //Esto representa una clase con un constructor con parametros
}

class OtraPersona //Esto es una clase con un constructor primario por defecto vacio


class Cliente //Clase generada con constructor por defecto
class Contacto(val id: Int, var email: String) //Clase que se genera con constructor con parametros


//Se crean clases para generar herencia, las que pueden ser padres herederos son clases abiertas

open class Perro {
    open fun saludar() {
        println("wow wow!")
    }
}


class Dalmata : Perro() { // En este caso el perro dalmata hereda de la clase abierta perro
    override fun saludar() { //Implementa la clase del padre sobreescribiendola hint: herencia override
        println("wuf wuf! U(O_O)U")
    }
}

//En el siguiente tipo de herncia la clase padre solicita un parametro, para poder rellenar su funcion saludar
//Cuando lo implementa clase tigre siberiano le puedo pasar el parametro que necesita su constructor de inmediato
open class Tiger(val origin: String) {
    fun saludar() {
        println("A tiger from $origin says: grrhhh!") } }

class TigreSiberiano : Tiger("Siberia")


//En el siguiente codigo se crea una clase padre que 2 solicita valores en su constructor
//Y la clase que hereda entrega uno de los dos parametros que necesita, en este caso
//El nombre del leon es lo que se solicitará y en el caso del origen se lo entregamos en la clase

open class Lion(val name: String, val origin:
String) {
    fun sayHello() {
        println("$name, the lion from $origin says: graoh!") } }

class Asiatic(name: String) : Lion(name = name, origin = "India")

//Data class es una clase especial que tiene getters y setters implicitos, tambien se les llama pojo
//En este caso los valores del constructor que se solicitan pasan a ser inmediatamente getters y setters

data class PersonaDos(val nombre: String, val rut: String, val edad: Int)

//Ejercicio con data class, se crea un usuario con data class
//Que en sus getters y setters busca el valor nombre y el identificador de usuario, se usará
//Asignacion de datos mediante la copia del usuario

data class User(val name: String, val id: Int)

//En el siguiente codigo se trabaja con generics
//Se crea la clase pila mutable del tipo generica que recibe por parametros vararg que son multiples argumentos del tipo generics

class MutableStack<E>(vararg items: E) {

    private val elements = items.toMutableList() // crea una variable privada que recibe una lista mutable
    fun push(element: E) = elements.add(element) //el tipo de elemento e recibe cualquier tipo de dato y añade a elements que es una lista mutable, el tipo de datos que escoja

    fun peek(): E = elements.last() //muestra el ultimo item de la lista
    fun pop(): E = elements.removeAt(elements.size - 1) //Permite remover elementos de la  lista
    fun isEmpty() = elements.isEmpty()//Prueba si la lista esta vacia
    fun size() = elements.size//Da el largo de la lista
    override fun toString() = "MutableStack(${elements.joinToString()})" //Usa el elemento e como tipo de retorno

}






fun main () {



    val cliente = Cliente()  // Se crea un nuevo oobjeto tipo cliente pero en kotlin se elimina la paalabra new para generar la instancia
    val contacto = Contacto(1, "Luffy@gmail.com") //Se crea un objeto de tipo contacto y se le asignan argumentos: un identificador y un email

    println(contacto.id)  //se imprime el identificador del contacto
    println()
    contacto.email = "jamiroqai@gmail.com" // Se actualiza email de contacto

    val persona = Persona("Soy una nueva persona") //Se crea una persona con una clase que imprime un texto
    val OtraPersona = OtraPersona() //Se crea un objeto del tipo Otra persona con el constructor vacio por defecto


    val perrito: Perro = Dalmata() //Creo un perro del tipo dalmata, posee herencia del padre
    perrito.saludar() //Saluda
    println()

    val tiger: Tiger = TigreSiberiano() //Creo el tigre siberiano que heredo de la clase tigre
    tiger.saludar() //El tigree ruge
    println()

    val lion: Lion = Asiatic("Rufo")//Le paso solo el parametro del nombre, el origen lo pase en la clase
    lion.sayHello()
    println()
    println()


    //Datos ingresados en una data class (Clase con getters y setters implicitos)
    val personaDos = PersonaDos("Evans", "19335563-8", 28)
    println("Nombre Persona = ${personaDos.nombre}") //Obtengo el dato de persona dos
    println()
    println("Rut Persona = ${personaDos.rut}")//Obtengo el dato de persona dos
    println("Edad Persona = ${personaDos.edad}")//Obtengo el dato de persona dos
    println()
    println()

    //Ejercicio de data class

    val user = User("Alex", 1) //Se crea un usuario llamado alex
    println(user) // se imprime el usuario
    println()
    val secondUser = User("Alex", 1) // Se crea un segundo Usuario con los mismos datos para comparar
    println(secondUser) //Imprimo los datos del segundo usuario
    println()
    val thirdUser = User("Max", 2) //Se crea un tercer usuario
    println("user == secondUser: ${user == secondUser}") //se realiza una comparacion de contenido con ==,
    //En kotlin no es lo mismo == que ===, == apunta a si las estructuras comparadas son iguales, a lo eqals en java
    //Mientras que === hace comparacion de refeerencia buscando si pertenecen al mismo objeto o punto en memoria?
    println()

    println("user == thirdUser: ${user == thirdUser}")// se compara el contenido de primer usuario con tercer usuario
    println()
    println(user.hashCode()) // devuelve el contenido de un objeto como numero entero
    println()
    println(thirdUser.hashCode())// devuelve el contenido del tercer usuario como numero entero o codigo hash
    // copy() function
    println(user.copy()) // Esta funcion permite copiar el usuario y lo imprime
    println()
    println(user.copy("Max"))  //Esta segunda función copia el usuario pero reemplaza el campo nombre Alex por "Max"
    println()
    println(user.copy(id = 2)) //Esta funcion hace lo mismmo que arriba pero le cambia el id explicitamente y lo imprime

    println()

    // Ejericio con Nulos, en general kotlin posee una regla especifica de que no acepta nulos
    //Solo en casos reservados

    var neverNull: String = "This can't be null" // En esta linea se asigna un valor
    // neverNull = null // Esta linea se comenta ya que sin el operador correcto
    // Kotlin lanza un error de compilacion
    var nullable: String? = "You can keep a null here" // En esta variable se puede mantener el valor nulo
    // Porque tiene el operador que permite que reciba tanto como un string como un nulo

    nullable = null // Se cambia el contenido string a nulo
    var inferredNonNull = "The compiler assumes non-null" //Cuando le asignas una variable

    //inferredNonNull = null // Cuando el ide infirio el tipo de variable en este caso string ya despues
    //cuando intentas asignar otro valor no cambia el tipo de dato ingresado, puedes ingresar string pero
    //Por ejemplo no puedes ingresar integer


    fun strLength(notNull: String): Int { //Esta funcion recibe una funcion String, y retorna un valor en este caso tipo entero que corresponde a
        //la cantidad de caracteres ingresados
        return notNull.length
    }


    val numeroCadena = strLength(neverNull) //
    println("se imprime el numero de caracteres de neverNull = $numeroCadena")


    //strLength(nullable)//En este punto si le asignas un null a la variable no reconoce como un valor valido
    //Ya que esta esperando que la variable que ingresa tenga un valor de tipo string y no nulo

    val stack = mutableStackOf(0.62, 3.14, 2.7) //Usa la funcion mutable stack que hace referencia a la clase mutable stack
    println(stack)



}

fun <E> mutableStackOf(vararg elements: E) =MutableStack(*elements) //Se pueden utilizar funciones del tipo generica

