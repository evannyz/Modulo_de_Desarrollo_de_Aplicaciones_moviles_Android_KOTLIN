package com.example.persistenciadatosroomapp.presentation

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.example.persistenciadatosroomapp.model.Task

class TaskViewModel(application: Application) :
    AndroidViewModel(application) {

    }