package com.example.persistenciadatosroomapp.model

import androidx.lifecycle.LiveData
import androidx.room.*

@Dao
interface TaskDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: Task)
    @Insert
    fun insertMultipleTask(list: List<Task>)
    @Update
    fun updateTask(task: Task)
    @Delete
    fun deleteOneTask(task: Task)
    @Query("SELECT * FROM task_table ORDER BY idTask ASC")
        fun getAllTask(): LiveData<List<Task>>
}