package com.example.tercerapptpartedos


import androidx.lifecycle.MutableLiveData


data class LibrosEscolares(val nombreLibro :String, val autor :String, val anioPublicacion: String, val editorial :String, val precio :Int, val nroPaginas :Int, val tipoLibro :String  ){


    fun formatearPrecio():String{
        return "$ $precio"
    }

    fun imprimirDatosDeLibro(){

        val precioFormateado = formatearPrecio()
        println("Nombre de libro: $nombreLibro")
        println("Nombre Autor: $autor")
        println("Año de Publicacion: $anioPublicacion")
        println("Editorial $editorial")
        println("Nro. de paginas: $nroPaginas")
        println("Precio de libro : $precioFormateado")
        println("Tipo de libro $tipoLibro")
        println()
        println()

    }

}




fun main(){

    var libroEscolarUno = LibrosEscolares( "Principito","Antonie de Saint Exupery","1944","Reynal",15000,123,"Digital")
    var libroEscolarDos = LibrosEscolares("Harry Potter y la piedra filosofal","J.K. Rowling","1997","Bloomsbury",20000,309,"Fisico")
    var libroEscolarTres = LibrosEscolares("Don Quijote de la Mancha","Miguel de cervantes", "1614","Francisco De Robles",30000, 1615, "Digital")
    val libroEscolarCuatro = LibrosEscolares("Farenheit 451","Ray Bradbury","1954","Por Agregar",25000, 272, "Fisico")

    libroEscolarUno.imprimirDatosDeLibro()
    libroEscolarDos.imprimirDatosDeLibro()
    libroEscolarTres.imprimirDatosDeLibro()
    libroEscolarCuatro.imprimirDatosDeLibro()





    // any sirve  para verificar que al menos un elemento en este caso de una lista cumpla las condiciones que establecemos

    val numbers = listOf(1, -2, 3, -4, 5, -6) //
    1
    val anyNegative = numbers.any { it < 0 }
// 2
    val anyGT6 = numbers.any { it > 6 }
    println()
    println()
    println(anyNegative)
    println(anyGT6)


    // All todos los elementos de la lista deven coincidir con la condicion para dar true

    val numbersDos = listOf(1, -2, 3, -4, 5, -6) //

    val allEven = numbersDos.all { it % 2 == 0 }
// 2
    val allLess6 = numbersDos.all { it < 6 }

    println()
    println()
    println(allEven)
    println(allLess6)

     // None ninguno de los elementos deben cumplir con la condicion para dar true

    val numbersTres = listOf(1, -2, 3, -4, 5, -6) //

    val allEvenDos = numbersTres.none { it % 2 == 1 }
// 2
    val allLess6Dos = numbersTres.none { it > 6 }

    println()
    println()
    println(allEvenDos)
    println(allLess6Dos)



    //find nos sirve para encontrar en un punto lo que busco con una condiccion

    val words = listOf("Lets", "find", "something", "in", "collection", "somehow") // 1
    val first = words.find { it.startsWith("some") } //El primero que encuentra que empiece con some

    val last = words.findLast { it.startsWith("some")//El ultimo que encuentra que empiece con some
    } // 3
    val nothing = words.find { it.contains("no")} //"palabras que contengan no


    //Sorted ordena por

    val shuffled = listOf(5, 4, 2, 1, 3) // Lista desordenada
    val natural = shuffled.sorted() // Lista ordenada por orden natural
    val inverted = shuffled.sortedBy { -it } // Lista ordenada al reves




}