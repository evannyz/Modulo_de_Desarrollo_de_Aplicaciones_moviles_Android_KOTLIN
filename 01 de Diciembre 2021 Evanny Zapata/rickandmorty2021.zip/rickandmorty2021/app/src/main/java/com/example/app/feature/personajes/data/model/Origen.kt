package com.example.app.feature.personajes.data.model

data class Origen(
    val name: String,
    val url: String
)

