package com.example.holamundokotlin

fun main() {

    println("Hola Mundo")
    val num: Int = 5

    println("num = $num")

    var number: Int = 6 //Declaración explicita, puedes declarar el tipo de variable
    val numberTwo = 7 //Declaración implicita, el ide infiere el tipo de valor a declarar

    println("number = $number and number2 = $numberTwo")

    var name = "Rebeca"
    val lastName = "Ramirez"

    println("El nombre ingresado es $name $lastName")

    var decimalNumber = 1.0
    println("decimalNumber = $decimalNumber")
    val bigDecimalNumber = 23.00f

    println("bigDecimalNumber = $bigDecimalNumber")


    // La palabra var o val.... Var es valor que se puede cambiar en cambio val es un valor inmutable
    // Prueba asignar un valor diferente a una variable tipo val y verás que el ide te dice que debes
    // Cambiar el tipo de variable
    // La variable recomendada es siempre val en lo posible

    var aDos = 10
    val e = "Goku"
    aDos = 20
    println("Variable mutable: $aDos")
    println("Variable inmutable: $e")

    val x: String = "valor String"
    val template = "Concatenando  **** $x **** valores"
    println(template)

    //Para concatenar basta anteponer el simbolo $ para los elementos del tipo string
    // Cuando una variable tiene algun metodo añadido como ver la cantidad de caraacteres que tiene
    // por ejemplo un tipo string, se utiliza las llaves {} para poder usar esass funciones
    //Ejemplo

    val xDos = "valor string"
    val templateDos = "Tiene ${xDos.count()} caracteres"
    println(templateDos)

    //Las siguientes lineas se definen variables de distintos tipos de datos y apreciamos
    //El tipo de variable que el ide infiere, al igual que en java el tipo flotante se ve con f o con F


    val entera = 30
    val cadena = "Luffy"
    val vocal = 'A'
    val flotante = 50F
    println("Variable Int: $entera")
    println("Variable String: $cadena")
    println("Variable Char: $vocal")
    println("Variable Float: $flotante")


    //Los valores numericos son identificados por la primera asignación de valor, por ejemplo si se
    // declara un valor sin puntos la variable por defecto sera integer, una vez asignada una variable
    // ya no se puedde cambiar el tipo de dato más adelante


    var a = 10
    val b = 33
    val c = 66
    var resultado = a + b + c
    println("$a + $b + $c = $resultado")
    a = 55
    resultado = a + b + c
    println("$a + $b + $c = $resultado")
    val promedio = resultado / 3
    println("Promedio : $promedio")

    //Existen distintos tipos de datos en kotlin al igual que java, en el caso de su rango maximo o
    // minimo se puede determinar con la funcion max_value o min_value,

    val byteMaximo = Byte.MAX_VALUE
    val byteMinimo = Byte.MIN_VALUE
    val shortMinimo = Short.MIN_VALUE
    val shortMaximo = Short.MAX_VALUE
    val intMinimo = Int.MIN_VALUE
    val intMaximo = Int.MAX_VALUE
    val longMinimo = Long.MIN_VALUE
    val longMaximo = Long.MIN_VALUE

    println("\nvalor max de short $shortMaximo")
    println("valor max de byte $byteMaximo")
    println("valor minimo de byte$byteMinimo")
    println("valor minimo de short$shortMinimo")
    println(intMaximo)
    println(intMinimo)
    println(longMaximo)
    println(longMinimo)

    //El tipo de valor por defecto que se estaablece cuando pones un valor con decimal es double
    //Si quieres un tipo de valor flotante, debes establecerlo con una f

    val floatNumber = 19.5f
    var doubleNumber: Double = 20.5

    println("El valor del numero flotante es $floatNumber")
    println("El valor del numero double es $doubleNumber")



    // Las funciones son prioritarias sobre las clases y funcion puede tener mas funciones o invocarlas
    // En estee caso fuera del main se declaara una funcion llamada getNombreCompleto y se invoca la misma
    // Mediante el uso de llaves { }

    println("funcion  nombre: ${obtenerNombreCompleto()}")

    // En Kotlin la manera de declarar parametros cambia ya que debes declarar el nombre de la variable junto
    // al tipo de dato ej nombre: String luego coma para separar y se empieza con la siguiente linea
    //La siguiente funcion se llama desde fuera de la funcion main y declara las variables de la manera
    //Mencionada anteriormente

    imprimirNombreCompleto("Evanny Fabian","Zapata Muñoz",31)

    //El siguiente metodo no necesita parametros y es del tipo vacio e imprime el valor del nombre Jennifer
    imprimirNombreCompletoDos()

    imprimirOtrasvariables()
    println(obtenerEdad()) // una forma de imprimir sin tener que declarar una variable de destino

    val edad = obtenerEdad()
    println("Usando .val  para imprimir el return dentro de una variable :$edad") // Lo mismo que arriba pero usando val


   // imprimo mensajes sin valor de retotrno
    printMessage("Este es un mensaje generico")

    //En el siguiente caso se imprimen valores con recomendación de llenado

     imprimeMensajeConPrefijo("mensaje aleatorio")  //la funcion tiene dos parametros tipo string que puedes completar pero
                                                            //no reclamara si solo le pones un mensaje string, ya que el otro tiene un mensaje
                                                            //default que se ejecuta si no recibe el argumento

    //Otra manera que permite ademas de solo ingresar mensajes es llamar directamente a los parametros como argumentos
    //Aunque no es necesario ya que esto lo hace el ide implicitamente
    imprimeMensajeConPrefijo(prefijo = "Log", mensaje = "Hello")

    //En el siguiente ejemplo se utiliza un metodo de retorno estandar explicito y la siquiente funcion
    //Utilizará un tipo de retorno implicito, las dos con .val +enter

    val suma = suma(1, 2)
    println("fun suma explicita = $suma")

    //Siguiente

    val multiplicacion = multiplicacion(5, 6)
    println("fun multiplicacion implicita = $multiplicacion")

    //Funciones con varArgs, varArgs significa una funcion puede recibir varios argumentos
    //En este caso varArgs se define en la funcion imprime t odo lo que

    imprimeTodo("Hola","Chao","Gatos","Perros","Calabaza","Zapallos","Hola mundo :D", "Adios mundo cruel :c")

    //En la siguiente funcion se imprimen la misma cantidad de datos qque en la funcion imprime t odo
    //Pero con la excepcion de que se imprimen con prefijo

    imprimeTodoConPrefijo("Hola","Chao","Gatos","Perros","Calabaza","Zapallos","Hola mundo :D", "Adios mundo cruel :c",
    prefijo = "Mensaje Añadido: ")


    //Las funciones por extensiòn nos permite usar extenciones para un tipo de dato, que pueden ser
    //covocados por el mismo tipo de variable, revisar la funcion String.saludo y String.despedida
    //Puede ser cualquier tipo de dato como por ejemplo int boolean etc

    var comodin = "comodin para explicar las funciones por extension"

    comodin.saludo();
    comodin.despedida();


}

fun obtenerEdad(): Int { //Retorno de tipo entero
    return 36

}

fun imprimirOtrasvariables() { //No se declara explicitamente pero la funcion es tipo Unit
    println("Es una funcion vacia por defecto")

}

fun imprimirNombreCompleto(nombres: String, apellidos: String, edad: Int){ //Parametros declarados
    println("Nombres: $nombres")
    println("Apellidos: $apellidos")
    println("Edad: $edad")

}

fun imprimirNombreCompletoDos():Unit{ //Tipo void ya que es tipo Unit
    println("Jenniffer Cornell")

}

fun obtenerNombreCompleto(): String { //REtorno de String
    return "Jenniffer Cornell"

}

fun printMessage(mensaje: String): Unit { // Retorno vacio ya que es tipo unit
    println(mensaje)

}

fun imprimeMensajeConPrefijo(mensaje: String, prefijo: String = "Info") {
    println("[$prefijo] $mensaje")
}

fun suma(x: Int, y: Int): Int {//3 lineas
    return x + y
}
                                            // 1 linea
fun multiplicacion(x: Int, y: Int) = x * y  // Es como la funcion sumar pero no declara ael tipo de variable que reotrna y el ide lo deduce


fun imprimeTodo(vararg mensaje: String) {
    for (m in mensaje)
        println(m) //En este caso imprime el valor de cada elemento m en el mensaje con un ciclo for
                    //Cada nuevo ingreso de mensaje se almacena en m---> es como un arraylist, investigar for each
                    // lo que hace m es tomar el valor de los argumentos que reciba y el ciclo for recorre lo que
                    //hay en m hasta que ya no hay nada que recorrer

}

fun imprimeTodoConPrefijo(vararg mensaje: String, prefijo: String) {
    for (m in mensaje) println(prefijo + m)
}

fun String.saludo() {// Este tipo de funcion es una extension de la clase String asi que solo una variable del mismo tipo la puede convocar
    println("Saludo") }

fun String.despedida() {//Esta tambièn funciona como la anterior
    println("chao") }