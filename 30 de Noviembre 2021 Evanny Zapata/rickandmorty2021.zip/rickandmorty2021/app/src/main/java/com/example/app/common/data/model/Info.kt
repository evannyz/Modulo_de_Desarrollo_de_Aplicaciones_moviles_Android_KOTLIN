package com.example.app.common.data.model

data class Info(
    val count : Int,
    val pages: Int,
    val next: String?,
    val prev: String?
)
