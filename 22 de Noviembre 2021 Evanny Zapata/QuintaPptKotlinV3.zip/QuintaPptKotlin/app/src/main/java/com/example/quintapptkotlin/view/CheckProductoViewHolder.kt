package com.example.quintapptkotlin.view

import androidx.recyclerview.widget.RecyclerView
import com.example.quintapptkotlin.databinding.ItemListLayoutBinding
import com.example.quintapptkotlin.model.Producto

class CheckProductoViewHolder(

    private val binding: ItemListLayoutBinding

): RecyclerView.ViewHolder(binding.root){

    fun bind(producto: Producto){

        with(binding) {
            tvNombreProducto.text = producto.nombre
            tvCantidadArticulos.text = producto.cantidad.toString()
            tvPrecioTotal.text = producto.total.toString()
        }

    }
}