package com.example.quintapptkotlin.presentation

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.quintapptkotlin.model.ConsumoDataBase
import com.example.quintapptkotlin.model.Producto
import com.example.quintapptkotlin.presentation.CheckListaProductoViewState.*
import kotlinx.coroutines.launch

class CheckProductoViewModel (
    private val consumosDatabase: ConsumoDataBase
) : ViewModel() {

        private val mutableState = MutableLiveData<CheckListaProductoViewState>()

        fun state(): LiveData<CheckListaProductoViewState> = mutableState

        fun initViewModel() {
            mutableState.postValue(LoadingViewState)
            viewModelScope.launch {
                try {
                    val responseItems = consumosDatabase.productoDao().getAll()
                    handleResponse(responseItems)
                } catch(e: Exception){
                    mutableState.postValue(ShowServerErrorViewState)
                }
            }
        }

        private fun handleResponse(responseItems: List<Producto>) {
            if(responseItems.isEmpty()){
                mutableState.postValue(ShowEmptyListViewState)
            } else {
                mutableState.postValue(
                    ShowCheckItemListViewState(
                        responseItems
                    )
                )
            }
        }

    }