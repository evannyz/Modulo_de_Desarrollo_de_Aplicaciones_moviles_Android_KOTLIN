package com.example.quintapptkotlin.presentation

import com.example.quintapptkotlin.model.Producto

sealed class CheckListaProductoViewState {
    object LoadingViewState : CheckListaProductoViewState()
    data class ShowCheckItemListViewState(val list: List<Producto>) : CheckListaProductoViewState()
    object ShowEmptyListViewState : CheckListaProductoViewState()
    object ShowServerErrorViewState : CheckListaProductoViewState()
}