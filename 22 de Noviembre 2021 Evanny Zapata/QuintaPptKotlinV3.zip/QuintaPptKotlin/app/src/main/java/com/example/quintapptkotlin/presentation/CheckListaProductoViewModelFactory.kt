package com.example.quintapptkotlin.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.quintapptkotlin.model.ConsumoDataBase

class CheckItemViewModelFactory(val consumosDatabase: ConsumoDataBase) : ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return modelClass.getConstructor(ConsumoDataBase::class.java)
            .newInstance(consumosDatabase)
    }
}