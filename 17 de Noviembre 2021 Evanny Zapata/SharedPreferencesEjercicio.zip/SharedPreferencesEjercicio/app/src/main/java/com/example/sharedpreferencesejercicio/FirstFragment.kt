package com.example.sharedpreferencesejercicio

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.example.sharedpreferencesejercicio.databinding.FragmentFirstBinding

/**
 * A simple [Fragment] subclass as the default destination in the navigation.
 */
class FirstFragment : Fragment() {


    //Companion object tiene un nombre y valor de constante
    companion object{
        private const val SHARED_PREF_NAME = "configuracion"
        private const val NUMERO_ENTERO_KEY = "numero_entero"
        private const val NUMERO_DECIMAL_KEY = "numero_decimal"
        private const val TEXTO_KEY = "texto"
        private const val SWITCH_KEY = "switch"
    }

    private lateinit var sharedPreferences : SharedPreferences

    private var _binding: FragmentFirstBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentFirstBinding.inflate(inflater, container, false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        configurarTodosLosClicks()
        iniciarSharedPreference()
        cargarValoresPorDefecto()


    }

    private fun configurarTodosLosClicks() {
        binding.run{

            btnBorrar.setOnClickListener{
                borrarValores()
            }

            btnGuardar.setOnClickListener {
                guardarValores()
            }

        }
    }

    private fun iniciarSharedPreference() {
        activity?.let { actividadSegura->
            sharedPreferences = actividadSegura.getSharedPreferences(
                SHARED_PREF_NAME,
                Context.MODE_PRIVATE
            )
        }// se llama desde la actividad porque estamos en el fragmento
    }

    private fun cargarValoresPorDefecto() {
        val numeroEntero= sharedPreferences.getInt(NUMERO_ENTERO_KEY,0)
        val texto = sharedPreferences.getString(TEXTO_KEY,"")
        val numeroDecimal = sharedPreferences.getFloat(NUMERO_DECIMAL_KEY,0.0f)
        val estadoSwitch = sharedPreferences.getBoolean(SWITCH_KEY,false)

        with(binding){
            tvMuestraNumEntero.setText(numeroEntero.toString())
            tvMuestraTexto.setText(texto)
            tvMuestraDecimal.setText(numeroDecimal.toString())
            swEstados.isChecked = estadoSwitch

        }
    }

    private fun guardarValores() {
        sharedPreferences.edit()
            .putString(TEXTO_KEY, binding.etIngresoTexto.text.toString())
            .putInt(NUMERO_ENTERO_KEY, binding.etIngresoNumEntero.text.toString().toInt())
            .putFloat(NUMERO_DECIMAL_KEY, binding.etIngresoNumDecimal.text.toString().toFloat())
            .putBoolean(SWITCH_KEY, binding.swEstados.isChecked)
            .apply()

    }

    private fun borrarValores() {
        sharedPreferences.edit()
            .putString(TEXTO_KEY, "")
            .putInt(NUMERO_ENTERO_KEY, 0)
            .putFloat(NUMERO_DECIMAL_KEY, 0.0f)
            .putBoolean(SWITCH_KEY, false)
            .apply()

        cargarValoresPorDefecto()

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}