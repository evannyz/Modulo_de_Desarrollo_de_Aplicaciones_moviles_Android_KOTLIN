package com.example.sharedpreferencesejercicio.model

import androidx.room.Database
import androidx.room.RoomDatabase


@Database(entities = [Producto::class], version = 1) //Enlazo con las entidades de mi clase
abstract class ConsumoDataBase:RoomDatabase() {
    abstract fun productoDao(): ProductoDao //Accedo a los datos del crud
}