package com.example.logingrupalapp.model

data class Usuario(val correo: String, val contraseña:String){
}