package com.example.logingrupalapp.model

import java.util.ArrayList

class ListaDeUsuariosYContraseñas {

    val listaDeUsuariosYContraseñas = ArrayList<Usuario>()
    



}