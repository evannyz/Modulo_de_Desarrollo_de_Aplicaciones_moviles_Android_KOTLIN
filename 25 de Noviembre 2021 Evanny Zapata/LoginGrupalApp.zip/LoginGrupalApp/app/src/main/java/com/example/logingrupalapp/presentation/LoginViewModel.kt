package com.example.logingrupalapp.presentation

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class LoginViewModel : ViewModel() {

    private val mutableLiveData = MutableLiveData<String>()

    fun state():LiveData<String> = mutableLiveData

    fun initViewModel(myString: String){

        viewModelScope.launch{
            mutableLiveData.postValue(myString)
        }
    }

}