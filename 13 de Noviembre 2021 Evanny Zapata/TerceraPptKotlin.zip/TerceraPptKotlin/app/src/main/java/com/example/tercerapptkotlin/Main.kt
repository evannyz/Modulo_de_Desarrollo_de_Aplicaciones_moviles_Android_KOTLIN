package com.example.tercerapptkotlin

 // Se crean clases globales para declarar variables en main que los contengan
class Raza {
    var nombre: String? = null
}
class Perro {
    var raza: Raza? = null
}






fun main(){

    for (i in 0 until 10) { //se imprimen los  valores desde el 0 hasta el 9 y se omite el 10
        print(i) }

    //En kotlin exixten los tipos de datos llamados pares y triples que sirven para manejar datos que vienen de esa manera
    // Con este ejemplo se manejan coordenadaas

    val coordinates: Pair<Int, Int> = Pair(2, 3) //variable : Tipo de dato tipo par( recibe genericos en este caso los dos de tipo entero)
    val coordinatesInferred = Pair(2, 3) //No declara el tipo de dato porque se infiere al asignarlo
    val coordinatesWithTo = 2 to 3  // Establece lo mismo que arriba pero con to
    val coordinatesDoubles = Pair(2.1, 3.5) //Infiere que el tipo de dato recibido sera doble por el ingreso de datos
    val coordinatesMixed = Pair(2.1, 3) //Infiere   que el primer dato de ingreso es doble y el siguiente entero
    val x1 = coordinates.first //se crea una variable x1 y de la variable coordenada se quita el primer par y se asigna a x1
    val y1 = coordinates.second //Lo mismo que lo anterior, esto es para poder manejar los datos individualmente
    val (x, y) = coordinates //Se puede crear en el caso de pares una variable de tipo par que reciba los pares de alguna otra fuente

    //Los triples se trabajan igual que los pares pero con una variable extra

    val coordinates3D = Triple(7, 3, 2)  //val (x3, y3, z3) = son coordenadas en 3 dimensiones
    val x3 = coordinates3D.first
    val y3 = coordinates3D.second
    val z3 = coordinates3D.third
    //Se usan igual que las pares


    //Existe un tipo de dato padre o madre llamado any  salvo los datos nulos
    //ESta clase acepta datos de otros tipos, como por ejemplo Strin o int

    val anyNumber: Any = 42
    println("anyNumber de tipo any = $anyNumber")
    println()
    val anyString: Any = "42"
    println("anyString de tipo any = $anyString")

    // a pesar de esto un tipo any no se puede por ejemplo sumar con un integer ej:

    val numeroEntero : Int = 10

    // var sumaResultante = anyNumber + numeroEntero // ya que no es lo mismo un objeto any que un entero primitivo

    //El operador elvis ?: es un tipo de dato no ternario que nos permite evitar los problemas con errores nulos
    //Ejemplo

    var nullableInt: Int? = 10 //Creo un tipo de dato que puede ser nulo, le asigno un tipo de dato numerico
    var mustHaveResult = nullableInt ?: 0 // Creo otra variable que recibe mi variable anterior y lo que
    //hace el operador en este caso es que si llegara a obtener un valor nulo desde la variable int por defecto se
    // omite el recibir un nullo y lo cambia por el cero y asi evito tener valores nulos


    var perro = Perro() //Creo mi variable del tipo perro
    perro.raza?.nombre // en la primera linea especifico que mi perro puede recibir valores nulos
   // perro.raza!!.nombre // pero en esta linea recibo error de compilacion porque el operador !! asegura que la variable no va a ser nunca nula
    //Lo que no se cumple porque la definimos del tipo nula



    // Se declara previamente una funcion de alto orden
    // y se crea una vaariable que obtenga los dos numeros y los sume
    //lo que retorna es una operacion con los dos valores


    val sumResult = calculate(4, 5, ::sum) //Los :: son una manera de llamar una funcion de manera rapida para entregarle los argumentos posteriormente

    val mulResult = calculate(4, 5) { a, b -> a * b } // En este caso se entregan los valores de la operacion y con la
    //funcion lambda se le entrega la operacion y luego se imprime, al final es lo mismo pero con más lineas de codigo
    println("sumResult $sumResult, mulResult$mulResult")


    //En el siguiente ejemplo de operacion se crea un nueva variable que es del tipo de la funcion operation
    //Y luego se imprime el resultado de la operacion del numero multiplicado por si mismo
    val func = operation()
    println(func(2))


    //En l siguiente ejercicio se trabaja con expreciones lambbda que son funciones a las que no se les
    //Antepone la palabra fun para declararlas simplemente{}

    //En el siguiente caso se demuestra la versatilidad de lambda ya que gracias a la inferencia de tipo
    //Se pueden declarar de muchas formas

    val upperCase1: (String) -> String = { str: String -> str.toUpperCase() } //Se crea una variable que recibe un string y retorna un string en este caso en minuscula y lo retorna en mayuscula
    val upperCase2: (String) -> String = { str -> str.toUpperCase() }

    val upperCase3 = { str: String -> str.toUpperCase() } // 3
    //val upperCase4 = { str -> str.toUpperCase() } // 4
    val upperCase5: (String) -> String = { it.toUpperCase() } // se usa it como un prefijo definido pero funciona commo el primer ejercicio

    val upperCase6: (String) -> String = String::toUpperCase //

    //En todos los casos se imprimira la variable en mayuscula

    println(upperCase1("hello"))
    println(upperCase2("hello"))
    println(upperCase3("hello"))
    println(upperCase5("hello"))
    println(upperCase6("hello"))


    //Se trabaja con elementos del tipo collections, ejemplo listas (no modificables)
    //mutables list ( lista que se puede manipular)
    //

    addSudoer(4) // Se agrega un nuevo usuario
    println("Tot sudoers: ${getSysSudoers().size}") // Se obtiene el total de usuarios
    getSysSudoers().forEach { // con un for each se recorre toda la lista y se imprime
            i -> println("Some useful info on user $i") }

    println()
    println()


    // getSysSudoers().add(5) <- Error! esta linea daria un error porque no se puede alterar una lista

    //Si necesitamos una coleccion que no pueda aceptar duplicados tenemos lo que se llama SET
    //Que corresponde a un tipo de coleccion desordenada

    val aNewIssue: String = "uniqueDescr4" //Ingresa un nuevo "asunto"  que no se encuentra en la lista
    val anIssueAlreadyIn: String = "uniqueDescr2"//Ingresa un nuevo "asunto"  que  se encuentra en la lista
    println("Issue $aNewIssue ${getStatusLog(addIssue(aNewIssue))}") //imprime el estado de registro del asunto nuevo
    println("Issue $anIssueAlreadyIn ${getStatusLog(addIssue(anIssueAlreadyIn))}")// Imprime el estado del asunto ya ingresado







}





//En kotlin existe un tipo de funcion llamada de alto orden que puede recibir como parametro otra funcion
//Esta funcion tiene el nombre de funcion de alto orden

fun calculate(x: Int, y: Int, operation: (Int, Int) -> Int): Int { // 1
    //calcular recibe 2 numeros de tipo entero y una operacion con dos enteros que devuelve solo un resultado entero
    //En este caso retorna la operacion con los dos valores ingresados
    return operation(x, y)

}
fun sum(x: Int, y: Int) = x + y
// 3


//En el siguiente caso una operacion puede retornar otra operacion

fun operation(): (Int) -> Int { // recibe un entero en una funcion y devuelve un entero en la funcion
    return ::square //REtorna la funcion de tipo cuadrado
}
fun square(x: Int) = x * x

//Se crean variables globales (Variables fuera del main y que tienen un ciclo de vida distinto) del tipo lista mutable, que pertenece a un tipo collection
//Que puede variar su contenido co una serie de metodos asociados

val systemUsers: MutableList<Int> = mutableListOf(1, 2, 3) //Se cargan 3 valores a la lista mutable

val sudoers: List<Int> = systemUsers //Se crea otra variable de tipo lista que no permite añadir
//Externamete nuevos elementos y se le asigna lo que esta en la lista mutable


fun addSudoer(newUser: Int) {
    systemUsers.add(newUser) } //Se añaden nuevos usuarios

fun getSysSudoers(): List<Int> {
    return sudoers           //REtorna los usuarios creados sin opcion de modificarlos
}


//Esta parte el profesor la hizo de otra manera, se necesita estudiar más  pero basicamente se
// crea una variable global que corresponde a un set mutable (osea que se puede modificar)
//y no permite duplicados

val openIssues: MutableSet<String> = mutableSetOf("uniqueDescr1", "uniqueDescr2", "uniqueDescr3") // 1

fun addIssue(uniqueDesc: String): Boolean {
    return openIssues.add(uniqueDesc) // ingresa
    }

fun getStatusLog(isAdded: Boolean): String { //Muestra el estado del registro, si se pudo o no registrar y lo devuelve como un string
    return if (isAdded){
        "registered correctly."
    }else {
        "marked as duplicate and rejected."
    }


    //Los siguientes datos son para trabajar con la colleccion map

    accountsReport() // 6
    updatePointsCredit(1) // 7
    updatePointsCredit(1)
    updatePointsCredit(5) // 8
    accountsReport()



    // funcion filter

    val numbers = listOf(1, -2, 3, -4, 5, -6) // Se crea una lista
    val positives = numbers.filter { x -> x > 0 } // se añade un filtro para que la variable positivo añada los valores superiores a 0 de la lista
    val negatives = numbers.filter { it < 0 } //  se añade un filtro para que la variable almacene los negativos

    //funcion map distinta a collecion map
    //funcion map

    val numbersTres = listOf(1, -2, 3, -4, 5, -6) // Creo una lista
    val doubled = numbersTres.map { x -> x * 2 } // multiplico tod_o el contenido por dos
    val tripled = numbersTres.map { it * 3 } // multiplico el contenido por tres


}


//En el siguiente codigo veremos la collection map que es distinta a la funcion
//Esto es como el ejemplo anterior, se declara un mapa mutable y otro no mutable


const val POINTS_X_PASS: Int = 15
val EZPassAccounts: MutableMap<Int, Int> = mutableMapOf(1 to 100, 2 to 100, 3 to 100) // Esto es lo mismo que usar
// (1,100),(2,100),(3,100) que corresponde al key y el value el key es una llave que identifica el registro y el 100
//En este caso son los puntos de una tarjeta osea al map mutable se le agregaron 3 registros con 100 puntos cada uno

val EZPassReport: Map<Int, Int> = EZPassAccounts //El reporte es para ver lo que hay sin modificarlo

fun updatePointsCredit(accountId: Int) { //Se crea funcion para poder sumar puntos de credito con la constante poitn pass
    if (EZPassAccounts.containsKey(accountId)) { // 3
        println("Updating $accountId...")
        EZPassAccounts[accountId] =
            EZPassAccounts.getValue(accountId) + POINTS_X_PASS // 4
    } else {
        println("Error: Trying to update a non-existing account (id:$accountId)")
    }
}

fun accountsReport() { //El reporte muestra la id y los puntos que tiene
    println("EZ-Pass report:")
    EZPassReport.forEach{ (k, v) -> println("ID $k: credit $v") }
}
