package com.example.app.feature.personajes.data.model

data class Location(
    val name: String,
    val url: String
)

