package com.example.app.feature.prelogin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.app.R

class BiometricActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_biometric)
    }
}