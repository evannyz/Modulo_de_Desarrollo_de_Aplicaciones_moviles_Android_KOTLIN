package com.example.app.feature.personajes.data.model

data class PersonajesResponse(
    val info: Info,
    val results: List<Personaje>
)