package com.example.filtrarlistaappkotlin

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.filtrarlistaappkotlin.databinding.FragmentFiltroListaBinding


class FiltroListaFragment : Fragment() {

    private var _binding: FragmentFiltroListaBinding? = null
    private val binding get() = _binding!!


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentFiltroListaBinding.inflate(inflater, container, false)
        return binding.root
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        asignarListaTextView()
        establecerLosClicksEnBotones()


    }

    private fun asignarListaTextView() {
        val listas = Listas()
        binding.tvMostrarListas.setText(
            "Sus listas disponibles son: \n Lista de numeros ${listas.numbersList.toString()}" +
                    "\n Lista de instancia: ${listas.instanceList.toString()} \n Lista de numeros tipo map ${listas.numbersMap.toString()} " +
                    "\n Listas de numeros desordenados : ${listas.unsortedList.toString()}"
        )
    }

    private fun establecerLosClicksEnBotones() {
        binding.run {

            btnFiltroUno.setOnClickListener {
                filtrarLosQueComienzanEnF()

            }

            btnFiltroDos.setOnClickListener {
                ordenarListaDesordenada()


            }

            btnFiltroTres.setOnClickListener {
                filtrarParValorQueContenganLlaves()


            }
        }
    }

    private fun filtrarLosQueComienzanEnF() {
        val lista2 = Listas()
        val filtro: (String) -> Boolean = { it.startsWith("f") }
        val listaFiltradaF = lista2.numbersList.filter(filtro)
        binding.tvMostrarListasFiltradas.setText(
            "Su lista filtrada corresponde a lista de numeros" +
                    "\nFiltrada por el criterio: 'Los que empiezan por f'" +
                    "\nSu lista filtrada es: ${listaFiltradaF.toString()}"
        )

    }

    private fun ordenarListaDesordenada() {
        val lista3 = Listas()
        val listaOrdenadaNumericamenteInverso = lista3.unsortedList.sortedBy { -it }
        binding.tvMostrarListasFiltradas.setText(
            "Su lista filtrada corresponde a lista de numeros desordenados" +
                    "\nFiltrada por el criterio: 'Ordenados por: orden descendente '" +
                    "\nSu lista filtrada es: ${listaOrdenadaNumericamenteInverso.toString()}"
        )

    }

    private fun filtrarParValorQueContenganLlaves() {
        val lista4 = Listas()
        val filtro: (Map.Entry<String, Int>) -> Boolean =
            { it.key.contentEquals("key2") || it.key.contentEquals("key3") }
        val listaFiltradaPorLlaves = lista4.numbersMap.filter(filtro)
        binding.tvMostrarListasFiltradas.setText("Su lista filtrada corresponde a lista de numeros tipo Map" +
                "\nFiltrada por el criterio: 'contenido de map con Llaves: key2 y key3 '" +
                "\nSu lista filtrada es: ${listaFiltradaPorLlaves.toString()}")
    }


}