package com.example.filtrarlistaappkotlin


 open class Listas {

     val numbersList = listOf("one", "five",
        "two", "three", "four")
     val instanceList = listOf(null, 1, "two",
        3.0, "four")
     val numbersMap = mapOf("key1" to 1,
        "key2" to 2, "key3" to 3, "key11" to 11)
     val unsortedList = listOf(7, 8, 5, 3, 2, 4)
 }