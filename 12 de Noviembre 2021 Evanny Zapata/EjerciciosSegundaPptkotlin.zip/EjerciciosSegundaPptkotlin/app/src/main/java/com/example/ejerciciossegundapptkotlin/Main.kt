package com.example.ejerciciossegundapptkotlin


fun main(){

    println("Mi nombre es ${nombreUsuario()}")

    println()

    val primer = 10
    val segundo = 20
    val tercer = 30

    val resultadoSuma = sumaVariables(primer,segundo,tercer)

    println("El resultado de su suma es $resultadoSuma")

    println()

    val valorString : String = "Ark Reigen"
    var valorChar: Char = 'A'

    println("La cantidad de caracteres de la variable String es ${valorString.length}")
    valorChar='B'

    println()

    var valorFloat: Float

    valorFloat = 10F

    val byteMax = "byteMax"
    val byteMin = "byteMin"
    val shortMin ="shortMin"
    val shortMax ="shortMax"
    println()
    imprimeValores(byteMax)
    println()
    imprimeValores(byteMin)
    println()
    imprimeValores(shortMax)
    println()
    imprimeValores(shortMin)
    println()

    val intMinimo = Int.MIN_VALUE
    val intMaximo = Int.MAX_VALUE
    val longMinimo = Long.MIN_VALUE
    val longMaximo = Long.MIN_VALUE

    println("Valor int minimo $intMinimo")
    println()
    println("Valor int maximo $intMaximo")
    println()
    println("Valor long minimo $longMinimo")
    println()
    println("Valor long maximo $longMaximo")
    println()

    var valorBooleano:Boolean = true

    println("El valor booleano tiene asignado : $valorBooleano")
    println()

    imprimeParametros("Cadena de caracteres Uno","Cadena dos")
    println()

    val obtieneIva = obtieneIva()
    println("El valor del iva es : $obtieneIva ")
    println()


    //Ciclo for de rango normal
    for (i in 0 .. 10) { // i in [0, 10), 10 is excluded
        print(i)
    }

    println()
    println()

    //Ciclo for con rango de valor excluido
    for (i in 0 until 10) { // i in [0, 10), 10 is excluded
        print(i)
    }




}


fun nombreUsuario():String{
    return "Evanny Zapata Muñoz"
}

fun sumaVariables(primer:Int, segundo: Int, tercer:Int): Int {

    val resultado = primer + segundo + tercer

    return resultado;

}

fun imprimeValores(valor : Any){

    when (valor) {
             "byteMax"-> println("Valor maximo de Byte ${Byte.MAX_VALUE}")
             "byteMin"-> println("Valor minimo de Byte ${Byte.MIN_VALUE}")
             "shortMin" ->println("Valor maximo de Short ${Short.MAX_VALUE}")
             "shortMax" -> println("Valor minimo de Short ${Short.MIN_VALUE}")
        else -> "Valor desconocido"

    }
}

fun imprimeParametros(paramUno:String, paramDos:String){

    var resultadoParametros = paramUno.length + paramDos.length

    println("La cantidad de caracteres de la primera cadena  mas la de los caracteres de la segunda es $resultadoParametros")
}

fun obtieneIva(): Float {

    val iva = 0.19F
    return iva

}