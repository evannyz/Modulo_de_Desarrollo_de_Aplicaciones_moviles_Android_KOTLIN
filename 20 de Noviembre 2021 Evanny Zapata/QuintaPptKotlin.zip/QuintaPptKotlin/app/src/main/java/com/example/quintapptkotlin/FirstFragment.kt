package com.example.quintapptkotlin

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.quintapptkotlin.databinding.FragmentFirstBinding
import com.example.quintapptkotlin.model.Producto
import com.example.quintapptkotlin.view.CheckProductoAdapter

/**
 * A simple [Fragment] subclass as the default destination in the navigation.
 */
class FirstFragment : Fragment() {

    private var _binding: FragmentFirstBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentFirstBinding.inflate(inflater, container, false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.buttonFirst.setOnClickListener {
            findNavController().navigate(R.id.action_FirstFragment_to_SecondFragment)
        }

        establecerRecyclerView()
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun establecerRecyclerView() {
        context?.let {
            val adapter = CheckProductoAdapter()
            adapter.establecerListaDeProductos(valoresFalsos())
            val layoutManager = LinearLayoutManager(context)
            with(binding){
                rvMuestraProducto.adapter = adapter
                rvMuestraProducto.layoutManager = layoutManager

            }
        }
    }

    fun valoresFalsos(): List<Producto>{

        val listaVacia = ArrayList<Producto>()

        for (indice in 1..10){ //Recorro una lista vacia con vacia
            listaVacia.add(crearElementoListaVacio(indice))

        }
            return listaVacia
    }

    private fun crearElementoListaVacio(indice: Int): Producto {
        return Producto(indice,"Producto $indice",indice,indice)
    }


}