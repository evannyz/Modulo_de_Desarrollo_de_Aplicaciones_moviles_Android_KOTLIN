package com.example.quintapptkotlin.model

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao
interface ProductoDao {

    @Query("SELECT*FROM Producto")
    fun getAll(): LiveData<List<Producto>>
    @Insert
    fun insertAll(vararg producto: Producto)

    @Update
    fun updateAll(vararg producto: Producto)

}