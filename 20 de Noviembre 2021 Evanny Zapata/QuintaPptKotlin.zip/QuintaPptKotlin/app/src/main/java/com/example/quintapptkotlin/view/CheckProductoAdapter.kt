package com.example.quintapptkotlin.view

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.quintapptkotlin.databinding.ItemListLayoutBinding
import com.example.quintapptkotlin.model.Producto

class CheckProductoAdapter() : RecyclerView.Adapter<CheckProductoViewHolder>() {


    private lateinit var listaDeProductos: List<Producto>

    fun establecerListaDeProductos(listaDeProductos: List<Producto>) {

        this.listaDeProductos = listaDeProductos
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CheckProductoViewHolder {
        val binding: ItemListLayoutBinding = ItemListLayoutBinding.inflate(
            LayoutInflater.from(parent.context),
            parent, false
        )
        return CheckProductoViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CheckProductoViewHolder, position: Int) {
        holder.bind(listaDeProductos[position])
    }

    override fun getItemCount(): Int {
        return listaDeProductos.size
    }


}