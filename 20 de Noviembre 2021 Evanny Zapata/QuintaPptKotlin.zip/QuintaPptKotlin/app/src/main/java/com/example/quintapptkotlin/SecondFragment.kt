package com.example.quintapptkotlin

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.NumberPicker
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.quintapptkotlin.databinding.FragmentSecondBinding
import com.example.quintapptkotlin.view.CheckProductoAdapter

/**
 * A simple [Fragment] subclass as the second destination in the navigation.
 */
class SecondFragment : Fragment() {

    private var _binding: FragmentSecondBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!



    //Inflo la vista
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentSecondBinding.inflate(inflater, container, false)
        return binding.root

    }
//Desde que la vista esta creada podemos trabajar
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        establecerDatosNumberPicker()

//
    }



    private fun establecerDatosNumberPicker() {

        binding.run {

            val minimoValorNumberPicker = 0
            npCantidadTotalProducto.minValue = minimoValorNumberPicker
            val maximoValorNumberPicker = 100
            npCantidadTotalProducto.maxValue = maximoValorNumberPicker

            npCantidadTotalProducto.setOnValueChangedListener(NumberPicker.OnValueChangeListener { picker, oldVal, newVal ->
                //
                var precio= precio()
                if(precio != 0) {
                    var obtenerPrecio = obtenerPrecio(precio, newVal)
                    var precioFormateado = precioFormateado(obtenerPrecio)
                    tvMostrarTotalProductoPrecio.setText("Cantidad Total:\n$precioFormateado")
                }else{
                    etIngresoPrecioUnidad.setError("Ingrese campo")
                    Toast.makeText(context,"Precio invalido",Toast.LENGTH_SHORT).show()
                }
            })
        }

    }

    private fun precio(): Int {
        return try {
            binding.etIngresoPrecioUnidad.text.toString().toInt()
        }catch (exception: NumberFormatException) {
            0
        }

    }

    private fun obtenerPrecio(precio: Int, newVal: Int): Int {
        return precio * newVal

    }

    private fun precioFormateado(obtenerPrecio: Int): String {

        return "$ $obtenerPrecio"

    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}