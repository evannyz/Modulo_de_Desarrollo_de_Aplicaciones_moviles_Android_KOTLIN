package com.example.loginintento8.presentation

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.loginintento8.data.model.Usuario
import com.example.loginintento8.data.UsuarioDB
import kotlinx.coroutines.launch

class LoginViewModel : ViewModel() {
    private val mutableLiveData = MutableLiveData<String>()

    fun state(): LiveData<String> = mutableLiveData
    fun login(usuario: String, contrasenia: String) {
        viewModelScope.launch {
            val usuario = UsuarioDB.loginConUsuarioYPassword(usuario, contrasenia)
            handleState(usuario)
        }
    }

    private fun handleState(usuario: Usuario?) {
        if (usuario != null) {
            mutableLiveData.postValue(usuario.nombreCompleto)
        } else {
            mutableLiveData.postValue("Usuario no existe")
        }

    }


}