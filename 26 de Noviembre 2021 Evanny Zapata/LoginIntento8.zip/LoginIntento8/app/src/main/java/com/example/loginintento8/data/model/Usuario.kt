package com.example.loginintento8.data.model

data class Usuario(
    val usuario: String,
    val nombreCompleto: String,
    val password: String
)