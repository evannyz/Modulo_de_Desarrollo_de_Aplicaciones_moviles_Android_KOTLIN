package com.example.loginintento8

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.activityViewModels
import com.example.loginintento8.databinding.FragmentLoginBinding
import com.example.loginintento8.presentation.LoginViewModel


class LoginFragment : Fragment() {


    private val loginViewModel: LoginViewModel by activityViewModels()
    private var rawBinding: FragmentLoginBinding? = null
    private val binding get() = rawBinding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        rawBinding = FragmentLoginBinding.inflate(inflater, container, false)
        return binding.root
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupClickListener()
        setupViewModel()
    }

    private fun setupViewModel() {
        loginViewModel.state().observe(this, {
            it?.let { safeState ->
                renderUi(safeState)
            }
        })
    }

    private fun renderUi(safeState: String) {
        Toast.makeText(context, safeState, Toast.LENGTH_LONG).show()
    }

    private fun setupClickListener() {
        binding.btnLogin.setOnClickListener {

            val usuario = binding.etUsuario.text.toString()
            val contrasenia = binding.etPassword.text.toString()

            loginViewModel.login(usuario, contrasenia)


        }
    }

}

